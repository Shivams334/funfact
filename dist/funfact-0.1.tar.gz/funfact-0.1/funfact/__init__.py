def fact():
	return('Banging your head against a wall burns 150 calories an hour')