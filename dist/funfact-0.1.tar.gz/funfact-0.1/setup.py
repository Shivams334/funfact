from setuptools import setup

setup(name='funfact',
      version='0.1',
      description='Some fun facts, thats it!',
      url='https://github.com/Shivams334/funfact.git',
      author='Shivam Sharma',
      author_email='shivams334@gmail.com',
      license='unlicense',
      packages=['funfact'],
      zip_safe=False)